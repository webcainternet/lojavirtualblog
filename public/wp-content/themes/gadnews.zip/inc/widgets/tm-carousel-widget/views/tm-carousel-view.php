<div class="inner">
	<header class="entry-header">
		<?php echo $image; ?>
		<div class="entry-content">
			<div class="post__cats"><?php echo $terms_line; ?></div>
			<?php echo $title; ?>
			<?php echo $content; ?>
			<?php echo $more_button; ?>
		</div>
	</header>
</div>