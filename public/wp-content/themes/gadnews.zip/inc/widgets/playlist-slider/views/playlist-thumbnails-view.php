<div class="sp-thumbnail">
	<?php echo $image; ?>
	<div class="thumbnail-content invert">
		<?php echo $title; ?>
	</div>
</div>