<div class="sp-slide sp-post-format-<?php echo $post_format; ?>">
	<div class="sp-slide-content invert">
		<div class="category"><?php echo $category; ?></div>
		<?php echo $title; ?>
		<div class="playlist-meta">
			<?php echo $date; ?>
			<?php echo $author; ?>
		</div>
		<div class="post_tag"><?php echo $tag; ?></div>
	</div>
	<div class="sp-slide-preview">
		<?php echo $slide; ?>
	</div>
</div>