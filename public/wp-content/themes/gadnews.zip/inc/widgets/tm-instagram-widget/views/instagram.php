<div class="instagram__item">
	<?php echo $image; ?>
	<?php echo $date; ?>
	<div class="instagram__caption"><?php echo $caption; ?></div>
</div>