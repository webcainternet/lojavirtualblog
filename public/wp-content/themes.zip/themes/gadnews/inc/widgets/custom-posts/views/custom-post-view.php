<div class="post <?php echo $grid_class; ?>">
	<div class="post-inner">
		<div class="post-image">
			<?php echo $image; ?>
		</div>
		<div class="post-content">
			<?php echo $category; ?>
			<?php echo $title; ?>
			<?php echo $excerpt; ?>
			<?php echo $date; ?>
			<?php echo $author; ?>
			<?php echo $count; ?>
			<?php echo $tag; ?>
			<?php echo $button; ?>
		</div>
	</div>
</div>